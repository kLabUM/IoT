/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <device.h>
#include <project.h>
#include "modem.h"
#include "packet.h"

// define global variables
#define WRITE_DEBUG 1
#define FEED_ID 1140560281

const char *API_KEY = "B0ZJ8np936O62JXlZtwOFlPD6cIZ0F5MpSyd7TLxihJsevIh";
char   data_packet[MAX_PACKET_LENGTH] = {0};
int    tmp, sign;
uint16 packet_len;

/* autosampler variables
uint8 t_sample, trigger_sampler, bottle_count, tmp;
*/
uint8   modem_get_time();
uint8   modem_check_network();
uint8   modem_get_signal_quality();
uint8   modem_get_serial_number();
uint8   modem_get_google();
uint8   modem_get_profile();
uint8   modem_set_flow_control(uint8 param);
uint8   modem_get_sw_version();

float   v_out;

void main()
{
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    CyGlobalIntEnable; /* Uncomment this line to enable global interrupts. */
    
    modem_set_api_feed(FEED_ID, API_KEY);
    
    ADC_SAR_1_Start();
    modem_start();
    modem_power_on();    
    modem_get_serial_number();
    
    // Check/set flow control: Changed from 3 (default - bidirectional) to 0 (no flow control) --> Did NOT fix ability to connect using AT#SD
    //modem_set_flow_control(0u); 
    //modem_get_profile(); //
    modem_get_sw_version();
    /* OLD MODEM CODE
    Telit_PWR_Write(0u); // 0u Enables power to cell module
    
    Telit_ON_Write(1u); 
    CyDelay(2000u);
    Telit_ON_Write(0u); 
    */    
    
    // Initialize variables
    tmp             = 0;
    sign            = 1;
    packet_len      = 0u;
    v_out           = 0.0;

    
    VBAT_READ_EN_Write(1u);
    Pin37_Write(0u);
    Pin38_Write(0u);
    Pin39_Write(0u);
    //Pin34_Write(0u);
    //Pin35_Write(0u);
    
    WaveDAC8_1_Start(); /* Start WaveDAC8  */

    for(;;)
    {
        /* Place your application code here. */
        Pin37_Write(!Pin37_Read());
        
        clear_packet(data_packet);
        sprintf(data_packet,"%s, %u\r\n",
        "tmp", tmp);
        
        modem_connect();
        LED_Write(!LED_Read());
        
        // modem_state should now be IDLE or READY
        modem_send_packet(data_packet);        
        //modem_get_google(); //Can't get to work
               
        if (tmp > 10) {
            sign = -1;
        } else if (tmp < -10) {
            sign = 1;
        }
        tmp = tmp + sign;        
        
        
        Pin37_Write(!Pin37_Read());
        LED_Write(!LED_Read());
        CyDelay(100u);  
        
        modem_get_time();
        Pin38_Write(!Pin38_Read());
        LED_Write(!LED_Read());
        CyDelay(100u);      
        
        modem_get_signal_quality();
        Pin39_Write(!Pin39_Read());
        LED_Write(!LED_Read());
        CyDelay(100u);  
        
        modem_check_network();
        //Pin34_Write(!Pin34_Read());
        LED_Write(!LED_Read());
        CyDelay(100u);  
        
        modem_get_serial_number();
        //modem_disconnect();
        //Pin35_Write(!Pin35_Read());
        LED_Write(!LED_Read());
        CyDelay(100u);   
        
        ADC_SAR_1_StartConvert();
        ADC_SAR_1_IsEndConversion(ADC_SAR_1_WAIT_FOR_RESULT);
        v_out = ADC_SAR_1_CountsTo_Volts(ADC_SAR_1_GetResult16());        
        //v_out = Pin30_Read();
        Pin25_Write(v_out);
    }
}

/* [] END OF FILE */
